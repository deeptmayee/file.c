#include <stdio.h>
int main(){
    int a=7;
    printf("The value is %d ",a);
    return 0;
}
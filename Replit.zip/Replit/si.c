#include <stdio.h>

int main() {
  
    
    float P = 100, R = 10, T = 1;

    
    float SI = (P * T * R) / 100;

    
    printf("Simple Interest = %f\n", SI);

    return 0;
}
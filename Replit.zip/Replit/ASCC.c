#include <stdio.h>

int main() {
    char c = 'x';
    printf("The ASCII value of %c is %d", c, c);
    return 0;
}
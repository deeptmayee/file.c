#include <stdio.h>
 
int main()
{
 
    int j = 30, b = 10;
    printf("Area of rectangle is : %d", j * b);
    printf("\nPerimeter of rectangle is : %d", 2 * (j + b));
    return 0;
}
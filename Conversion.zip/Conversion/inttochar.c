
#include <stdio.h>


int main()
{
	int N = 103;
	printf("%c", (char)(N));
	return 0;
}

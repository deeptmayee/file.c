#include <stdio.h> 
  
int main() 
{ 
    int decimalNumber = 45; 
 
    printf("Hexadecimal number is: %X", decimalNumber); 
    return 0; 
}
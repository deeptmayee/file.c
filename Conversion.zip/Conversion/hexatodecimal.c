#include <stdio.h> 

int main() 
{ 

	int n; 

	scanf("%x", &n); 

	printf("%d", n); 
	return 0; 
}

#include <stdio.h>
#include <string.h>

int main() {
    char s[] = "Ashish";
    printf("%lu", strlen(s));
    return 0;
}
